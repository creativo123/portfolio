import sys

print("Month\tDebit\tCredit")
i = "-1"
debit = 0.0
credit = 0.0
for row in sys.stdin:
    line = row.strip().split("\t")
    if line[0] == i:
        rs = float(line[1])
        if(rs >= 0):
            debit = debit + float(line[1])
        else:
            credit = credit + (rs*-1)
    else:
        if(i != "-1"):
            print("{0}\t{1}\t{2}".format(i,str(round(debit,2)),str(round(credit,2))))
        i = line[0]
        debit = 0
        credit = 0
        rs = float(line[1])
        if(rs >= 0):
            debit = debit + float(line[1])
        else:
            credit = credit + (rs*-1)

print("{0}\t{1}\t{2}".format(i,str(round(debit,2)),str(credit)))

        
        
