import csv
import sys
import time

reader = csv.reader(sys.stdin,delimiter = ',',quotechar = '"')
next(reader)
for row in reader:
    if len(row)!= 7:
        continue
    t = time.strptime(row[0],"%d-%b-%y")
    try:
        rs = float(row[4].replace(',',''))
        round(rs,2)
    except:
        rs = float(row[5].replace(',',''))*-1
        #round(rs,2)
    print("{0}-{1}\t{2}".format(time.strftime("%b",t),time.strftime("%y",t),rs))
